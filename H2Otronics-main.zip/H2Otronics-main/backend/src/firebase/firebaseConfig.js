import admin from "firebase-admin";
import dotenv from "dotenv";
import express, { json } from "express";
import { createRequire } from "module";

const require = createRequire(import.meta.url);

// const serviceAccount = require("/Users/user/coding/h20/backend/serviceKey.json");

const serviceAccount = JSON.parse(process.env.FIREBASE_ADMIN_KEY);

dotenv.config();

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// admin.initializeApp({
//   credential: admin.credential.cert(serviceAccount),
// });

if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert({
      projectId: serviceAccount.project_id,
      clientEmail: serviceAccount.client_email,
      privateKey: serviceAccount.private_key.replace(/\\n/g, "\n"),
    }),
  });
}

export const db = admin.firestore();
export const auth = admin.auth();
export default admin;
